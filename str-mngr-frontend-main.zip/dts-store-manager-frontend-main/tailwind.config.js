/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: 'class',
  content: ['./src/**/*.{html,js,jsx}', 'node_modules/flowbite-react/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: '#ff8c00',
        'primary-text': '#444',
        'secondary-text': '#777',
        'primary-bg': '#fff',
        'secondary-bg': '#f3f3f3',
        shadow: '#d1d1d1',
        border: '#ddd',
      },
    },
  },
  plugins: [require('flowbite/plugin')],
};
