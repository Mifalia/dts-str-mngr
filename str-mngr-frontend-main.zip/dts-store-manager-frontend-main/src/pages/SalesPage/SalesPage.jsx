import React, { useEffect, useState } from 'react';

import { Modal, Spinner, Table } from 'flowbite-react';
import { DateCalendar } from '@mui/x-date-pickers';
import dayjs from 'dayjs';
import StoreApi from 'services/StoreApi';
import { useDispatch, useSelector } from 'react-redux';
import { setItemList } from 'store/slices/item-slice';
import { setSaleList } from 'store/slices/sale-slice';
import { BiSolidCommentAdd } from 'react-icons/bi';
import { AiOutlineCheck } from 'react-icons/ai';
import { RxCross1 } from 'react-icons/rx';

import { Button, FormControl, InputLabel, MenuItem, Select, TextField } from '@mui/material';

const SalesPage = () => {
  const itemList = useSelector((store) => store.ITEM.itemList);
  const saleList = useSelector((store) => store.SALE.saleList);

  const dispatch = useDispatch();
  const [selectedDate, setSelectedDate] = useState(() => dayjs(new Date().toDateString()));
  const [isLoading, setIsLoading] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [currentQuantity, setCurrentQuantity] = useState(1);
  const [showModal, setShowModal] = useState(false);
  const [totalPrice, setTotalPrice] = useState(0);

  const handleDateChange = (value) => {
    const date = new Date(value);
    setSelectedDate(dayjs(date.toDateString()));
  };

  const loadItems = async () => {
    try {
      let response = await StoreApi.getItems();
      const { status } = response;
      if (status !== 200) {
        console.log('Impossible de chercher les produits');
        return 0;
      }
      const items = await response.json();
      await dispatch(setItemList({ items }));
    } catch (error) {
      alert('Impossible de se connecter au serveur distant, vérifiez vos paramètres de connexion');
    }
  };

  const loadSales = async () => {
    let response = await StoreApi.getSales({ d: selectedDate.format('YYYY-MM-DD') });
    if (!response) alert('Impossible de chercher les ventes');
    const { status } = response;
    if (status === 200) {
      const sales = await response.json();
      await dispatch(setSaleList({ sales }));
    }
  };

  const submitSale = async () => {
    let response = await StoreApi.createSale({ itemId: selectedItem.id, quantity: currentQuantity });
    const { status } = response;
    if (status !== 201) {
      alert("Une erreur s'est produite lors de l'enregistrement de cette vente");
      return 0;
    }
    setShowModal(false);
    setIsLoading(true);
    await loadSales();
    setIsLoading(false);
  };

  useEffect(() => {
    if (!itemList || !saleList) {
      setIsLoading(true);
    } else {
      setIsLoading(false);
    }
  }, [itemList, saleList]);

  useEffect(() => {
    loadItems();
  }, []);

  useEffect(() => {
    console.log({ selectedItem, currentQuantity });
  }, [selectedItem, currentQuantity]);

  useEffect(() => {
    loadSales();
  }, [selectedDate]);

  useEffect(() => {
    console.log({ itemList });
    console.log({ saleList });
    console.log({ selectedDate });
  }, [itemList, saleList]);

  useEffect(() => {
    if (saleList?.length > 0) {
      let finalTotal = 0;
      for (let sale of saleList) {
        finalTotal += parseInt(sale.unit_price) * parseInt(sale.quantity);
      }
      setTotalPrice(finalTotal);
    }
  }, [saleList]);

  if (isLoading)
    return (
      <div className='h-screen flex justify-center items-center'>
        <Spinner size={'xl'} />
      </div>
    );

  return (
    <div className='flex'>
      <div className='h-screen flex-1 p-4 flex flex-col'>
        <div className='overflow-y-scroll custom-scrollbar flex-1 px-8'>
          <Modal
            show={showModal}
            size='md'
            onClose={() => {
              setShowModal(false);
            }}
          >
            <Modal.Header>Enregistrer une vente</Modal.Header>
            <Modal.Body>
              <>
                <FormControl fullWidth>
                  <InputLabel id='item-name'>Nom de la marchandise</InputLabel>
                  <Select
                    labelId='item-name'
                    label='Nom de la marchandise'
                    fullWidth
                    defaultValue={selectedItem}
                    placeholder='Sélectionnez la marchandise'
                    onChange={(e) => setSelectedItem(() => itemList.find((item) => item.id == e.target.value))}
                  >
                    {itemList?.map((item, index) => (
                      <MenuItem value={item.id} key={index}>
                        {' '}
                        {item.name}{' '}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
                <TextField
                  label='Quantité'
                  name='quantity'
                  fullWidth
                  margin='dense'
                  type='number'
                  defaultValue={currentQuantity}
                  onChange={(e) => setCurrentQuantity(() => parseFloat(e.target.value))}
                />
                <TextField
                  label='Prix unitaire'
                  name='unit-price'
                  fullWidth
                  margin='dense'
                  value={selectedItem?.sale_price}
                />
                <TextField
                  className='bg-secondary'
                  label='Total'
                  name='total-price'
                  fullWidth
                  margin='dense'
                  color='success'
                  value={selectedItem !== null ? parseInt(selectedItem?.sale_price) * parseFloat(currentQuantity) : 0}
                />
              </>
            </Modal.Body>
            <Modal.Footer>
              <Button variant='outlined' color='warning'>
                <RxCross1 size={24} />
              </Button>
              <Button
                variant='outlined'
                color='success'
                disabled={!selectedItem || currentQuantity == 0}
                onClick={() => submitSale()}
              >
                <AiOutlineCheck size={24} />
              </Button>
            </Modal.Footer>
          </Modal>
          <h1 className='text-center h-8 mt-2 mb-4 font-bold'>
            {' '}
            <span className='bg-gray-300 text-gray-900 rounded-full p-2'>{selectedDate.format('DD MMMM YYYY')}</span>
          </h1>
          {saleList?.length > 0 ? (
            <>
              <Table>
                <Table.Head>
                  <Table.HeadCell>Nom de la marchandise</Table.HeadCell>
                  <Table.HeadCell>Quantité</Table.HeadCell>
                  <Table.HeadCell>Prix Unitaire</Table.HeadCell>
                  <Table.HeadCell>Prix Total</Table.HeadCell>
                </Table.Head>
                <Table.Body>
                  {saleList?.map((sale, index) => {
                    return (
                      <Table.Row key={index}>
                        <Table.Cell> {itemList?.find((item) => item.id === sale.item_id)?.name} </Table.Cell>
                        <Table.Cell> {sale.quantity} </Table.Cell>
                        <Table.Cell> {sale.unit_price} </Table.Cell>
                        <Table.Cell className='text'> {sale.unit_price * sale.quantity} </Table.Cell>
                      </Table.Row>
                    );
                  })}
                  <Table.Row className='bg-white'>
                    <Table.Cell></Table.Cell>
                    <Table.Cell></Table.Cell>
                    <Table.Cell></Table.Cell>
                    <Table.Cell>
                      <p className='text font-bold text-green-500'> {totalPrice + ' Ariary'} </p>
                    </Table.Cell>
                  </Table.Row>
                </Table.Body>
              </Table>
            </>
          ) : (
            <>
              <div className='flex flex-col justify-center items-center h-full '>
                <BiSolidCommentAdd
                  color=''
                  className='text-gray-500 hover:text-gray-600 hover:cursor-pointer'
                  size={64}
                  onClick={() => setShowModal(true)}
                />
                <p className='font-bold py-4 text-gray-500'>Aucune vente enregistrée pour ce jour</p>
              </div>
            </>
          )}
        </div>
        {saleList?.length > 0 && (
          <div className='flex flex-row justify-center items-center' style={{ height: '80px' }}>
            <Button variant='outlined' className='rounded-full' size='large' onClick={() => setShowModal(true)}>
              Nouvelle vente +
            </Button>
          </div>
        )}
      </div>
      <div className='flex flex-col items-center'>
        <DateCalendar
          value={selectedDate && selectedDate}
          onChange={(value) => handleDateChange(value)}
          shouldDisableDate={(date) => date.$W === 0}
          disableFuture
        />
      </div>
    </div>
  );
};

export default SalesPage;
