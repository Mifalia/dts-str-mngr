import React, { useState } from 'react';

import { TextField } from '@mui/material';

import StoreApi from 'services/StoreApi';
import { useDispatch } from 'react-redux';
import { setUser } from 'store/slices/user-slice';
import { useNavigate } from 'react-router-dom';
import BlankLayout from 'layouts/BlankLayout/BlankLayout';

const LoginPage = () => {
  // local states
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = async () => {
    let response = await StoreApi.login({ email, password });
    // console.log(response);
    /*
     */
    if (response === null) {
      alert('Impossible de se connecter au serveur distant');
      return 0;
    }

    const { status } = response;

    if (status === 403) {
      alert('Email ou mot de passe erroné');
      return 0;
    }

    if (status === 200) {
      response = await response.json();
      let { id, username, email, token, isAdmin } = response;
      await dispatch(setUser({ id, username, email, token, isAdmin }));
      navigate('/');
    }
    // console.log(response);
  };

  // ===== RENDERING ===== //
  return (
    <BlankLayout>
      <div className='bg-white rounded-lg drop-shadow-lg flex flex-col items-center p-10' style={{ width: '25rem' }}>
        <h1 className='text-3xl font-semibold mb-6'>S'identifier</h1>
        <form
          className='w-full p-0'
          onSubmit={(e) => {
            e.preventDefault();
            handleSubmit();
          }}
        >
          <div className='my-5'>
            <TextField
              name='email'
              label='Email'
              type='email'
              id='email'
              size='medium'
              variant='outlined'
              className='w-full'
              onChange={(e) => {
                setEmail(e.target.value);
              }}
            />
          </div>
          <div className='my-5'>
            <TextField
              name='password'
              label='Mot de passe'
              type='password'
              id='email'
              size='medium'
              variant='outlined'
              className='w-full'
              color=''
              onChange={(e) => {
                setPassword(e.target.value);
              }}
            />
          </div>
          <button type='submit' className='mt-2 text-white text-center bg-primary w-full h-12 rounded'>
            Continuer
          </button>
        </form>
      </div>
    </BlankLayout>
  );
};

export default LoginPage;
