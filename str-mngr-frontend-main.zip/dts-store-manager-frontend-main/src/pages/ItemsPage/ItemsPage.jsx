import { Button, ButtonGroup, TextField } from '@mui/material';
import ItemsTableContainer from 'containers/ItemsTable/ItemsTableContainer';
import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import StoreApi from 'services/StoreApi';
import { setItemList } from 'store/slices/item-slice';
import { RxCross1 } from 'react-icons/rx';
import { GoTrash } from 'react-icons/go';
import { AiOutlineCheck } from 'react-icons/ai';

const ItemsPage = () => {
  const dispatch = useDispatch();
  // component datas
  const [currentItemId, setCurrentItemId] = useState();
  const [currentItemName, setCurrentItemName] = useState('');
  const [currentItemInitialPrice, setCurrentItemInitialPrice] = useState(0);
  const [currentItemSalePrice, setCurrentItemSalePrice] = useState(0);

  // methods
  const loadItems = async () => {
    try {
      let response = await StoreApi.getItems();
      const { status } = response;
      if (status !== 200) {
        console.log('Impossible de chercher les notes');
        return 0;
      }
      const items = await response.json();
      await dispatch(setItemList({ items }));
    } catch (error) {
      alert('Impossible de se connecter au serveur distant, vérifiez vos paramètres de connexion');
    }
  };

  const handleSubmit = async () => {
    if (!currentItemId) await createCurrentItem();
    else await updateCurrentItem();
  };

  const createCurrentItem = async () => {
    let response = await StoreApi.createItem({
      name: currentItemName,
      initial_price: currentItemInitialPrice,
      sale_price: currentItemSalePrice,
    });
    console.log({ response });
    response = await response.json();
    console.log({ response });
  };

  const updateCurrentItem = async () => {
    let response = await StoreApi.updateItem({
      id: currentItemId,
      name: currentItemName,
      initial_price: currentItemInitialPrice,
      sale_price: currentItemSalePrice,
    });

    console.log({ response });
    response = await response.json();
    console.log({ response });
  };
  const handleCancel = async () => {
    setCurrentItemId(null);
    setCurrentItemName('');
    setCurrentItemInitialPrice(0);
    setCurrentItemSalePrice(0);
  };

  const handleRowClick = (item) => {
    setCurrentItemId(item.id);
    setCurrentItemName(item.name);
    setCurrentItemInitialPrice(item.initial_price);
    setCurrentItemSalePrice(item.sale_price);
  };

  // hooks
  useEffect(() => {
    loadItems();
  });

  useEffect(() => {
    console.log(currentItemName);
  }, [currentItemName]);

  // rendering
  return (
    <div className='flex flex-row'>
      <div className='flex-1 px-8 py-4 h-screen overflow-y-scroll custom-scrollbar'>
        <h1 className='text-center font-bold text-2xl mb-4'>Liste des produits en vente</h1>
        <ItemsTableContainer onRowClick={handleRowClick} />
      </div>
      <div className='w-1/3 bg-white rounded px-4 py-4 m-4 ml-0'>
        <h1 className='text-lg mb-8 font-semibold text-center'>
          {!currentItemId ? 'Ajouter un produit' : 'Modifier le produit'}{' '}
        </h1>
        <form>
          <TextField
            value={currentItemName}
            fullWidth
            margin='dense'
            name='name'
            label='Nom du produit'
            onChange={(e) => setCurrentItemName(e.target.value)}
          />
          <TextField
            value={currentItemInitialPrice}
            fullWidth
            margin='dense'
            name='initial-price'
            label='Prix d`achat en ariary'
            type='number'
            onChange={(e) => setCurrentItemInitialPrice(parseInt(e.target.value))}
          />
          <TextField
            value={currentItemSalePrice}
            fullWidth
            margin='dense'
            name='sale-price'
            label='Prix de revente en ariary'
            type='number'
            onChange={(e) => setCurrentItemSalePrice(parseInt(e.target.value))}
          />

          <div className='w-full mt-6 flex flex-row justify-center items-center gap-x-2' size='large'>
            <Button className='' type='reset' variant='outlined' disableElevation onClick={() => handleCancel()}>
              <RxCross1 size={24} />
            </Button>
            {currentItemId && (
              <Button variant='outlined' color='warning'>
                <GoTrash size={24} />
              </Button>
            )}
            <Button
              className=''
              variant='contained'
              disableElevation
              onClick={() => {
                handleSubmit();
              }}
            >
              <AiOutlineCheck size={24} />
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ItemsPage;
