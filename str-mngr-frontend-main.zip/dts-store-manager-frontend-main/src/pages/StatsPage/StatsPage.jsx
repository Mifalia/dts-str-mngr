import React, { useEffect, useState } from 'react';
import StoreApi from 'services/StoreApi';
import { DateCalendar, MonthCalendar, YearCalendar } from '@mui/x-date-pickers';
import { LineChart } from '@mui/x-charts/LineChart';
import { ChartContainer, BarPlot } from '@mui/x-charts';

import dayjs from 'dayjs';

const StatsPage = () => {
  const [selectedDate, setSelectedDate] = useState(() => dayjs(new Date().toDateString()));
  const [salesList, setSalesList] = useState([]);
  const [chartData, setChartData] = useState([]);
  const [chartSeries, setChartSeries] = useState([]);

  const handleDateChange = (value) => {
    const date = new Date(value);
    setSelectedDate(dayjs(date.toDateString()));
  };

  const loadSales = async () => {
    let response = await StoreApi.getSales({ d: selectedDate.format('YYYY-MM-DD'), monthly: true });
    if (!response) alert('Impossible de chercher les ventes');
    const { status } = response;
    if (status === 200) {
      response = await response.json();
      setSalesList(response);
      console.log({ response });
    }
  };

  const generateChartData = async () => {
    if (!salesList) return 0;
    const startDate = new Date(selectedDate.format('YYYY-MM-DD'));
    startDate.setDate(1);
    const endDate = new Date(startDate);
    endDate.setMonth(endDate.getMonth() + 1);
    // endDate.setDate(endDate.getDate() - 1)

    console.log({ startDate });
    //console.log({endDate})

    let dataArray = [];
    let dateArray = [];

    for (let date = startDate; date < endDate; date.setDate(date.getDate() + 1)) {
      if (!(date.getDay() === 0)) {
        const foundRows = salesList.filter((sale) => date.getDate() === new Date(sale.createdAt).getDate());
        // console.log({foundRows})

        let total = 0;
        for (let row of foundRows) {
          total += parseInt(row.quantity) * parseInt(row.unit_price);
        }

        dataArray[date.getDate()] = total;
        dateArray[date.getDate()] = date.getDate();
      }
    }
    dataArray = dataArray.filter((data) => data !== undefined);
    dateArray = dateArray.filter((data) => data !== undefined);

    setChartData(dataArray);
    setChartSeries(dateArray);

    //console.log(dataArray);
    //console.log(dateArray);
  };

  const calculateMonthTotal = () => {
    if (chartData) {
      let total = 0;
      for (let data of chartData) {
        total += data;
      }

      return total;
    }

    return 0;
  };

  useEffect(() => {
    loadSales();
  }, [selectedDate]);

  useEffect(() => {
    generateChartData();
  }, [salesList]);

  useEffect(() => {
    console.log({ chartSeries });
  }, [chartSeries]);

  useEffect(() => {
    console.log({ chartData });
  }, [chartData]);

  return (
    <div className='flex flex-row'>
      <div className='flex-1 flex flex-col items-center justify-end'>
        <LineChart
          xAxis={[{ data: chartSeries.length > 0 ? chartSeries : [0, 0] }]}
          series={[
            {
              data: chartData.length > 0 ? chartData : [0, 0],
              area: false,
            },
          ]}
          curve='linear'
          width={756}
          height={400}
        />

        <p>
          <b>Mois :</b> {selectedDate.format('MMMM YYYY')}{' '}
        </p>
        <p>
          <b>Total chiffre de vente:</b> {calculateMonthTotal() + ' Ariary'}
        </p>
      </div>

      <div className=''>
        <h1 className='text-center font-bold py-4'>Sélectionner le mois</h1>
        <MonthCalendar
          value={selectedDate && selectedDate}
          onChange={(value) => handleDateChange(value)}
          shouldDisableDate={(date) => date.$W === 0}
          disableFuture
        />
        <h1 className='text-center font-bold py-4'>Sélectionner l'année</h1>
        <div className='h-40'>
          <YearCalendar
            className=''
            value={selectedDate && selectedDate}
            onChange={(value) => handleDateChange(value)}
            shouldDisableDate={(date) => date.$W === 0}
            disableFuture
          />
        </div>
      </div>
    </div>
  );
};

export default StatsPage;
