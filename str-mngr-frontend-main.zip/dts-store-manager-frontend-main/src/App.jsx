import React from 'react';
import { Provider } from 'react-redux';

import store from 'store';
import AppRouter from './routes/AppRouter';
import { LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';

const App = () => {
  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <Provider store={store}>
        <AppRouter />
      </Provider>
    </LocalizationProvider>
  );
};

export default App;
