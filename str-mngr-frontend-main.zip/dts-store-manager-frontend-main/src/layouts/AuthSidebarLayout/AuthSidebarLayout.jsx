import React, { useEffect } from 'react';

import { HiOutlineUserCircle } from 'react-icons/hi';
import { MdOutlinePointOfSale, MdExitToApp } from 'react-icons/md';
import { LiaBoxesSolid } from 'react-icons/lia';
import { AiOutlineLineChart } from 'react-icons/ai';
import { FaUsersGear } from 'react-icons/fa6';
import { Sidebar } from 'flowbite-react';

import { Outlet, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';

const AuthSidebarLayout = ({ children }) => {
  const navigate = useNavigate();
  const userId = useSelector((store) => store.USER.id);

  useEffect(() => {
    if (!userId) {
      navigate('/login');
    }
  });

  if (userId)
    return (
      <div className='bg-secondary-bg h-screen flex'>
        <div className='h-screen'>
          <Sidebar aria-label='Default sidebar example' className=''>
            <Sidebar.Items>
              <div className='flex flex-col'>
                <div className='flex-1'>
                  <Sidebar.ItemGroup>
                    <Sidebar.Item
                      className='cursor-pointer'
                      onClick={() => navigate('/')}
                      icon={MdOutlinePointOfSale}
                      label='Principale'
                      labelColor='dark'
                    >
                      <p>Caisse</p>
                    </Sidebar.Item>
                  </Sidebar.ItemGroup>

                  <Sidebar.ItemGroup>
                    <Sidebar.Item
                      icon={AiOutlineLineChart}
                      className='cursor-pointer'
                      onClick={() => navigate('/stats')}
                    >
                      <p>Statistiques</p>
                    </Sidebar.Item>
                    <Sidebar.Item onClick={() => navigate('/items')} icon={LiaBoxesSolid} className='cursor-pointer'>
                      <p>Gérer les produits</p>
                    </Sidebar.Item>
                    <Sidebar.Item href='#' icon={FaUsersGear} className='cursor-pointer'>
                      <p>Gérer les utilisateurs</p>
                    </Sidebar.Item>
                    <Sidebar.Item href='#' icon={HiOutlineUserCircle} className='cursor-pointer'>
                      <p>Compte personnel</p>
                    </Sidebar.Item>
                  </Sidebar.ItemGroup>
                </div>

                <Sidebar.ItemGroup color='success'>
                  <Sidebar.Item onClick={() => navigate('/login')} icon={MdExitToApp} className='cursor-pointer'>
                    <p>Fermer la session</p>
                  </Sidebar.Item>
                </Sidebar.ItemGroup>
              </div>
            </Sidebar.Items>
          </Sidebar>
        </div>
        <div className='flex-1'>{children ? children : <Outlet />}</div>
      </div>
    );
};

export default AuthSidebarLayout;
