import BlankLayout from 'layouts/BlankLayout/BlankLayout';
import React from 'react';
import { useSelector } from 'react-redux';
import { AiFillWarning } from 'react-icons/ai';

function AdminLayout({ children }) {
  const isAdmin = useSelector((store) => store.USER.isAdmin);

  if (isAdmin !== true) {
    return (
      <>
        <BlankLayout>
          <AiFillWarning color='' className='text-gray-500' size={64} />
          <p className='font-bold py-4 text-gray-500'>
            Vous n'avez pas les permissions nécessaires pour acceder à cette section
          </p>
        </BlankLayout>
      </>
    );
  }

  return <>{children}</>;
}

export default AdminLayout;
