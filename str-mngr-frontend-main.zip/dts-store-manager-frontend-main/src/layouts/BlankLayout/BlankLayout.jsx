import React from 'react';

const BlankLayout = ({ children }) => {
  return <div className='h-screen bg-secondary-bg flex flex-col justify-center items-center p-0'>{children}</div>;
};

export default BlankLayout;
