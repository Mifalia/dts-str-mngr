const BASE_URL = 'http://localhost:8000/';

class StoreApi {
  // ===== LOGIN REQUEST ==== //
  static async login({ email, password }) {
    try {
      // defining body
      const requestBody = new URLSearchParams();
      requestBody.append('email', email);
      requestBody.append('password', password);

      // request
      let response = await fetch(BASE_URL + 'login/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: requestBody,
      });

      return response;
    } catch (error) {
      console.log(error);
      return null;
    }
  }

  // ===== ITEMS RELATIVE REQUESTS ===== //
  static async getItems() {
    const items = await fetch(BASE_URL + 'items/');
    return items;
  }

  static async createItem({ name, initial_price, sale_price }) {
    try {
      const requestBody = new URLSearchParams();
      requestBody.append('name', name);
      requestBody.append('initial_price', parseInt(initial_price));
      requestBody.append('sale_price', parseInt(sale_price));

      console.log(requestBody);

      // request
      let response = await fetch(BASE_URL + 'items/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: requestBody,
      });

      return response;
    } catch (error) {
      console.log(error);
      return null;
    }
  }

  static async updateItem({ id, name, initial_price, sale_price }) {
    try {
      const requestBody = new URLSearchParams();
      requestBody.append('name', name);
      requestBody.append('initial_price', parseInt(initial_price));
      requestBody.append('sale_price', parseInt(sale_price));
      console.log(requestBody);

      // request
      let response = await fetch(BASE_URL + 'items/' + id, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: requestBody,
      });

      return response;
    } catch (error) {
      console.log(error);
      return null;
    }
  }

  // ====== Sales related ===== //
  static async getSales({ d, monthly = false }) {
    try {
      let response = await fetch(BASE_URL + 'sales?d=' + d + '&monthly=' + monthly);
      return response;
    } catch (error) {
      console.log(error);
      return null;
    }
  }

  static async createSale({ itemId, quantity, description = '' }) {
    try {
      const requestBody = new URLSearchParams();
      requestBody.append('item_id', itemId);
      requestBody.append('quantity', parseInt(quantity));
      requestBody.append('description', description);

      let response = await fetch(BASE_URL + 'sales/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: requestBody,
      });

      return response;
    } catch (error) {
      console.log(error);
      return null;
    }
  }
}

export default StoreApi;
