import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

import AuthSidebarLayout from 'layouts/AuthSidebarLayout/AuthSidebarLayout';
import LoginPage from 'pages/LoginPage/LoginPage';
import SalesPage from 'pages/SalesPage/SalesPage';
import ItemsPage from 'pages/ItemsPage/ItemsPage';
import StatsPage from 'pages/StatsPage/StatsPage';

function AppRouter() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path='/login' element={<LoginPage />} />
        <Route path='/' element={<AuthSidebarLayout />}>
          <Route path='/' element={<SalesPage />} />
          <Route path='/items' element={<ItemsPage />} />
          <Route path='/stats' element={<StatsPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default AppRouter;
