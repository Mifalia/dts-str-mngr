const { createSlice } = require('@reduxjs/toolkit');

const itemSlice = createSlice({
  name: 'item-slice',
  initialState: {
    itemList: [],
  },

  reducers: {
    setItemList: (currentSlice, actions) => {
      currentSlice.itemList = actions.payload.items;
    },
  },
});

const { setItemList } = itemSlice.actions;

export { setItemList };
export default itemSlice;
