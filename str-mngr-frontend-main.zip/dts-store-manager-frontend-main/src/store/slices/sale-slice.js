const { createSlice } = require('@reduxjs/toolkit');

const saleSlice = createSlice({
  name: 'sale-slice',
  initialState: {
    saleList: [],
  },
  reducers: {
    setSaleList: (currentSlice, actions) => {
      const { sales } = actions.payload;
      currentSlice.saleList = sales;
    },
  },
});

const { setSaleList } = saleSlice.actions;

export { setSaleList };
export default saleSlice;
