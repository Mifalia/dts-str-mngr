import { createSlice } from '@reduxjs/toolkit';

const userSlice = createSlice({
  name: 'user-slice',
  initialState: {
    id: '',
    username: '',
    email: '',
    token: '',
    isAdmin: null,
  },

  reducers: {
    setUser: (currentSlice, actions) => {
      const { id, email, username, token, isAdmin } = actions.payload;
      currentSlice.id = id;
      currentSlice.email = email;
      currentSlice.username = username;
      currentSlice.isAdmin = isAdmin;
      currentSlice.token = token;
    },
  },
});

const { setUser } = userSlice.actions;

export { setUser };
export default userSlice;
