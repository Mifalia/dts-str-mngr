import { configureStore } from '@reduxjs/toolkit';

import userSlice from './slices/user-slice';
import itemSlice from './slices/item-slice';
import saleSlice from './slices/sale-slice';

const store = configureStore({
  reducer: {
    USER: userSlice.reducer,
    ITEM: itemSlice.reducer,
    SALE: saleSlice.reducer,
  },
});

export default store;
