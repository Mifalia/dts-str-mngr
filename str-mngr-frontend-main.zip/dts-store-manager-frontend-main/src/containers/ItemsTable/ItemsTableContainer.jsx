import { Table } from 'flowbite-react';
import React from 'react';
import { useSelector } from 'react-redux';

const ItemsTableContainer = ({ onRowClick }) => {
  // data
  const items = useSelector((store) => store.ITEM.itemList);

  // methods

  return (
    <div className='bg-white'>
      <Table hoverable>
        <Table.Head>
          <Table.HeadCell>Nom du produit</Table.HeadCell>
          <Table.HeadCell align='center'>Prix d'achat</Table.HeadCell>
          <Table.HeadCell align='center'>Prix de revente</Table.HeadCell>
          <Table.HeadCell align='center'>Bénéfice net par pièce</Table.HeadCell>
        </Table.Head>
        <Table.Body className='divide-y'>
          {items.map((item, index) => (
            <Table.Row key={index} onClick={() => onRowClick(item)} className='cursor-pointer'>
              <Table.Cell> {item.name} </Table.Cell>
              <Table.Cell align='center' className=''>
                {' '}
                {item.initial_price} Ar
              </Table.Cell>
              <Table.Cell align='center' className='font-extrabold text-black'>
                {' '}
                {item.sale_price} Ar
              </Table.Cell>
              <Table.Cell align='center' className='text-green-500'>
                {' '}
                {item.sale_price - item.initial_price} Ar
              </Table.Cell>
            </Table.Row>
          ))}
        </Table.Body>
      </Table>
    </div>
  );
};

export default ItemsTableContainer;
