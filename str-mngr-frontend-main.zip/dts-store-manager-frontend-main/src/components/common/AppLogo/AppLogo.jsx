import React from 'react';

const AppLogo = ({ size }, props) => {
  return <div>AppLogo</div>;
};

export default AppLogo;
