// imports
var express = require("express");
var path = require("path");
var cookieParser = require("cookie-parser");
var logger = require("morgan");

// routes and middleware imports
var headersMiddleware = require("./src/middlewares/headers");
var indexRouter = require("./src/routes/index");
var usersRouter = require("./src/routes/users");
var itemsRouter = require("./src/routes/items");
var loginRouter = require("./src/routes/login");
var salesRouter = require("./src/routes/sales");

// models definitions imports
require("./src/models/");

var app = express();

// different config middlewares
app.use(logger("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));
// setting headers
app.use(headersMiddleware);

// ROUTES BEGIN HERE
app.use("/", indexRouter);
app.use("/users", usersRouter);
app.use("/items", itemsRouter);
app.use("/login", loginRouter);
app.use("/sales", salesRouter);

module.exports = app;
