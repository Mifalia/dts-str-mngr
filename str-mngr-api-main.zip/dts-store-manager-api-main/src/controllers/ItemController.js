const Item = require('../models/Item');
const Unit = require('../models/Unit');
const { ItemValidator } = require('../services/ItemValidator');

const ItemController = {
    // # retrieve all items # //
    /** @type import("express").RequestHandler */
    getAllItems: async (req, res) => {
        const itemList = await Item.findAll();
        res.json(itemList);
    },

    // # get by id # //
    getItemById: async (req, res) => {
        const id = req.params.id;
        const item = await Item.findByPk(id);
        if (!item) res.status(404).json({ message: 'item not found' });
        else res.json(item);
    },

    // # get by id # //
    createNewItem: async (req, res) => {
        const request = req.body;
        console.log(request);

        // extracting item keys from user's request
        const item = {
            name: request.name && request.name.trim(),
            initial_price: request.initial_price && request.initial_price,
            sale_price: request.sale_price && request.sale_price,
        };

        /* 
      checking every field of the request body
      extracting the validated value from Item validator
    */
        const { error, value } = ItemValidator.validate(item);

        // handling eventual errors
        if (error) {
            res.status(400).json({ message: error.details });
            return 0;
        }

        // saving to database
        const newItem = await Item.create(value);

        // rendering
        res.status(201).json(newItem);
    },

    // # delete item based on a provided id # //
    deleteItem: async (req, res) => {
        // extracting id from url
        const id = req.params.id;

        try {
            // fetching item from database
            const item = await Item.findByPk(id);
            // checking if item exists
            if (!item) {
                res.status(404).json({
                    message: "Can't delete item, item not found",
                });
                return 0;
            }
            // deleting item from database
            await item.destroy();
            // rendering a response
            res.status(200).json({ message: 'Item deleted successfully' });
        } catch (error) {
            console.error('Error occurred while deleting the row:', error);
        }
    },

    // # update existing item # //
    updateItem: async (req, res) => {
        // extracting id from url params
        const id = req.params.id;
        const request = req.body;
        try {
            // retrieving the object from database
            const item = await Item.findByPk(id);
            // checking if item exists
            if (!item) {
                res.status(404).json({
                    message: "Can't update item, item not found",
                });
                return 0;
            }
            const itemData = {
                name: request.name && request.name.trim(),
                initial_price: request.initial_price,
                sale_price: request.sale_price,
            };

            // checking if new values are valid for update
            const { error, value } = ItemValidator.validate(itemData);

            // checking eventual validation errors
            if (error) {
                res.status(400).json({ message: error.details });
                return 0;
            }

            // attribuating the validated values to the item and pushing changes into database
            item.set({ ...value });
            await item.save();

            // rendering json item
            res.status(200).json(item);
        } catch (error) {
            console.error('Error occurred while update the row:', error);
        }
    },
};

module.exports = ItemController;
