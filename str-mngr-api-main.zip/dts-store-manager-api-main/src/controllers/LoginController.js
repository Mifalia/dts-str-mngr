var jwt = require('jsonwebtoken');
var bcrypt = require('bcrypt');

const User = require('../models/User');
const { JWT_SECRET_KEY, JWT_EXPIRATION } = require('../middlewares/auth/constants');

const LoginController = {
  // # authenticate user via email and password # //
  login: async (req, res) => {
    try {
      // extracting email and password from request, and removing unnecessary whitespaces
      var { email, password } = req.body;
      email = email?.trim();
      // checking the existense of email and password from request
      if (!email) return res.status(403).json({ message: 'Please provide a valid email for authentication' });
      if (!password) return res.status(403).json({ message: 'Please provide a password' });
      // fetching user with provided email from database
      const userFound = await User.findOne({ where: { email: email.trim() } });
      // checking if user is existing
      if (!userFound) return res.status(403).json({ message: 'No user with the provided email was found' });
      // comparing password from request to the one from database
      const isValidPassword = await bcrypt.compare(password, userFound.password);
      if (!isValidPassword) return res.status(403).json({ message: 'Incorrect password' });
      // generating a jwt token when user's credentials have passed verifications
      const jwtPayload = {
        id: userFound.id,
        username: userFound.username,
        isAdmin: userFound.isAdmin,
      };
      const token = await jwt.sign(jwtPayload, JWT_SECRET_KEY, { expiresIn: JWT_EXPIRATION });
      var { id, isAdmin, username, email } = userFound;
      // rendering
      return res.status(200).json({ message: 'Login success', token, id, isAdmin, username, email });
      // handling internal errors
    } catch (error) {
      console.log(error);
      return res.status(500);
    }
  },
};

module.exports = LoginController;
