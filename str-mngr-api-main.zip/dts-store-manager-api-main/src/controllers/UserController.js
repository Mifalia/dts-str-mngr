const bcrypt = require("bcrypt");

const User = require("../models/User");
const { UserPasswordValidator, UserDataValidator } = require("../services/UserValidator");

const UserController = {
  // # get all Users # //
  getAllUsers: async (req, res) => {
    const users = await User.findAll();
    return res.status(200).json(users);
  },

  // # get a specific user based on a given id # //
  getUserById: async (req, res) => {
    // extracting id from request
    const id = req.params.id;
    // checking if user provided an id in his request
    if (!id) return res.status(400).json({ message: "No id provided" });
    // fetching user from database
    const user = await User.findByPk(id);
    // handling the eventuality of no user found
    if (!user) return res.status(404).json({ message: "No user found" });
    // rendering a response to the client side
    return res.status(200).json(user);
  },

  // # create an User # //
  createUser: async (req, res) => {
    try {
      // retrieving data from cliend request
      const { username, email, password, password_confirm } = req.body;
      // checking password and passwordConfirmation equality with custom validator
      const passwordValidation = UserPasswordValidator.validate({
        password,
        password_confirm,
      });
      // checking data with custom validator
      const dataValidation = UserDataValidator.validate({
        username: username.trim(),
        email: email.trim(),
      });
      // handling eventual validation error
      if (passwordValidation.error) return res.status(400).json(passwordValidation.error.details);
      if (dataValidation.error) return res.status(400).json(dataValidation.error.details);
      // checking if User already exists in database
      const existingUser = await User.findOne({ where: { email } });
      if (existingUser) return res.status(409).json({ message: "Email is already used by another user" });
      // generating hashed password
      const saltRounds = 10;
      const hashedPassword = await bcrypt.hash(passwordValidation.value.password, saltRounds);
      // saving to database
      const newUser = await User.create({
        ...dataValidation.value,
        password: hashedPassword,
      });
      // rendering result if no errors
      return res.status(201).json(newUser);
    } catch (error) {
      console.log(error);
    }
  },
  // # delete an User # //

  // # modify user informations # //
};

module.exports = UserController;
