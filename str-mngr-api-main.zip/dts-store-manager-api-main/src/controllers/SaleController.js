const { Op } = require('sequelize');

const SaleValidator = require('../services/SaleValidator');
const Sale = require('../models/Sale');
const Item = require('../models/Item');

const SaleController = {
  // ====== GET SALES ===== //
  /** @type import('express').RequestHandler */
  getSales: async (req, res) => {
    let { d, monthly } = req.query;
    d = d?.trim();
    console.log({ monthly });
    // monthly = monthly?.trim();

    let sales = [];

    if (!d) {
      // if no date is specified, fetching all rows from database
      sales = await Sale.findAll();
    } else {
      if (monthly == 'true') {
        const startDate = new Date(d);
        startDate.setDate(1);
        console.log(startDate.toDateString());
        const endDate = new Date(startDate);
        endDate.setMonth(startDate.getMonth() + 1);
        console.log(endDate.toDateString());
        sales = await Sale.findAll({
          where: {
            createdAt: {
              [Op.between]: [startDate, endDate],
            },
          },
        });
      } else {
        const startDate = new Date(d);
        const endDate = new Date(startDate.getTime() + 1000 * 60 * 60 * 24);
        sales = await Sale.findAll({
          where: {
            createdAt: {
              [Op.between]: [startDate, endDate],
            },
          },
        });
      }
    }

    return res.status(200).json(sales);
  },

  // ===== GET SALE BY ID ===== //;;
  getSaleById: async (req, res) => {
    const { id } = req.params;
    const saleFound = await Sale.findByPk(id);
    if (!saleFound) return res.status(404).json({ message: 'No item found' });
    return res.status(200).json(saleFound);
  },

  // ===== CREATE A NEW SALE ===== //
  createSale: async (req, res) => {
    // extracting necessary data from request
    var { quantity, item_id, description } = req.body;
    // making data to be ready for validation
    const sale = { quantity, item_id, description: description?.trim() };
    // validating data
    const { error, value } = SaleValidator.validate(sale);
    // checking eventual validation errors
    if (error) return res.status(400).json(error.details);
    // fetching the provided item_id from database
    const item = await Item.findByPk(value.item_id);
    if (!item)
      return res.status(404).json({ message: 'Item provided not found' });

    // if no errors, stocking the item into database
    var { description, quantity, item_id } = value;
    const saleToStore = {
      description,
      quantity,
      item_id,
      unit_initial_price: item.initial_price,
      unit_price: item.sale_price,
    };

    const newSale = await Sale.create(saleToStore);

    return res.status(201).json(newSale);
  },

  // ===== DELETE SALE  ===== //
  deleteSale: async (req, res) => {
    //
    const { id } = req.params;
    const saleFound = await Sale.findByPk(id);
    //
    if (!saleFound) return res.status(404).json({ message: 'No item found' });
    //
    await saleFound.destroy();
    //
    return res.status(200).json({ message: 'Sale deleted successfully' });
  },
};

module.exports = SaleController;
