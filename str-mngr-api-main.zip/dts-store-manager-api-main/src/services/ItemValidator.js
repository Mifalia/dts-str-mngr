const Joi = require('joi');

const ItemValidator = Joi.object({
  id: Joi.alternatives().try(Joi.number().integer(), Joi.string()).optional(),
  name: Joi.string().min(2).required(),
  initial_price: Joi.number().integer().positive().required(),
  sale_price: Joi.number().integer().positive().required(),
});

const IdValidator = Joi.alternatives().try(Joi.number().integer(), Joi.string()).optional();

module.exports = { ItemValidator, IdValidator };
