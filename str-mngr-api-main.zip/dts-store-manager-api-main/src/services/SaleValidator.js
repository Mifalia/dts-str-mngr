const Joi = require("joi");

const SaleValidator = Joi.object({
  quantity: Joi.number().required(),
  item_id: Joi.alternatives().try(Joi.number().integer(), Joi.string()).required(),
  description: Joi.string().min(0).optional(),
});

module.exports = SaleValidator;
