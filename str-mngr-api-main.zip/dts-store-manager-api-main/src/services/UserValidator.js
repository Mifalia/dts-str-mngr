const Joi = require("joi");

const UserDataValidator = Joi.object({
  id: Joi.alternatives().try(Joi.number().integer(), Joi.string()).optional(),
  username: Joi.string().min(4).max(48).required(),
  email: Joi.string().email().required(),
});

const UserPasswordValidator = Joi.object({
  password: Joi.string().min(8).required(),
  password_confirm: Joi.string().min(8).valid(Joi.ref("password")).required(),
});

module.exports = { UserDataValidator, UserPasswordValidator };
