const jwt = require("jsonwebtoken");

const { JWT_SECRET_KEY } = require("./constants");

const userAuth = async (req, res, next) => {
  // extracting authorization header from user's request
  const authorizationHeader = req.headers.authorization;
  if (!authorizationHeader) return res.status(401).json({ message: "Please provide a valid token" });
  // extracting Beare token from authorization header
  const token = authorizationHeader.replace("Bearer", "").trim();
  // checking the validity of the token provided
  try {
    const decoded = await jwt.verify(token, JWT_SECRET_KEY);

    // from there I think it's done; if token verification fails, we will fall into the catch(){} block
    next();

    // handling jwt exception;
    // example : Invalid token, expired token, other token exceptions ...
  } catch (error) {
    return res.status(403).json({ message: "Invalid token", details: error });
  }
  // handling eventual token errors
};

module.exports = userAuth;
