const crypto = require("crypto");

const JWT_SECRET_KEY = process.env.JWT_SECRET_KEY || crypto.randomBytes(32).toString("hex");
const JWT_EXPIRATION = "14h";

module.exports = { JWT_SECRET_KEY, JWT_EXPIRATION };
