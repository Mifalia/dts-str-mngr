const express = require("express");
const router = express.Router();

const adminAuth = require("../middlewares/auth/adminAuth");
const userAuth = require("../middlewares/auth/userAuth");

const SaleController = require("../controllers/SaleController");

router.get("/", SaleController.getSales);
router.get("/:id", SaleController.getSaleById);
router.post("/", SaleController.createSale);
router.delete("/:id", SaleController.deleteSale);

module.exports = router;
