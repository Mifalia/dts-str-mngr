var express = require("express");
const router = express.Router();

//
const ItemController = require("../controllers/ItemController");

// ROUTES BEGIN HERE
router.get("/", ItemController.getAllItems);
router.get("/:id", ItemController.getItemById);
router.post("/", ItemController.createNewItem);
router.delete("/:id", ItemController.deleteItem);
router.put("/:id", ItemController.updateItem);

module.exports = router;
