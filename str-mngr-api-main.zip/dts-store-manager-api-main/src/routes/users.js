var express = require("express");
var router = express.Router();

const UserController = require("../controllers/UserController");
const userAuth = require("../middlewares/auth/userAuth");
const adminAuth = require("../middlewares/auth/adminAuth");

/* GET users listing. */
router.get("/", UserController.getAllUsers);
router.get("/:id", UserController.getUserById);
router.post("/", UserController.createUser);

module.exports = router;
