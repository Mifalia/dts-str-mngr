const Sequelize = require("sequelize");
const config = require("../config/db-config.json");

const DB = config.DATABASE;
const USERNAME = config.USERNAME;
const PASSWORD = config.PASSWORD;
const HOST = config.HOST;
const PORT = config.PORT;
const DB_TYPE = config.DIALECT;

const sequelize = new Sequelize(DB, USERNAME, PASSWORD, { host: HOST, port: PORT, dialect: DB_TYPE });

module.exports = sequelize;
