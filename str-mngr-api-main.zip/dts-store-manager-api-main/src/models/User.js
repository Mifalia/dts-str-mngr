const { DataTypes, Sequelize } = require("sequelize");
const sequelize = require("./config");

const User = sequelize.define(
  "User",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },

    // Other fields of the User model
    username: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    password: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    isAdmin: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },

    // Timestamp fields
  },
  {
    tableName: "users",
    timestamps: true, // Disable Sequelize's default timestamp fields (updatedAt, createdAt)
  }
);

sequelize
  .sync()
  .then(() => {
    console.log("User model synced with database");
  })
  .catch((error) => {
    console.error("Error syncing User model:", error);
  });

module.exports = User;
