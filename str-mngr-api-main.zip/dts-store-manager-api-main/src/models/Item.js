const { DataTypes, Sequelize } = require("sequelize");
const sequelize = require("./config");

const Item = sequelize.define(
  "Item",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },

    // Other fields of the User model
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },

    initial_price: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },

    sale_price: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },

    // Timestamp fields
  },
  {
    tableName: "items",
    timestamps: true, // Disable Sequelize's default timestamp fields (updatedAt, createdAt)
  }
);

sequelize
  .sync()
  .then(() => {
    console.log("Item model synced with database");
  })
  .catch((error) => {
    console.error("Error syncing User model:", error);
  });

module.exports = Item;
