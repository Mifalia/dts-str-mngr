const { DataTypes } = require("sequelize");
const sequelize = require("./config");

const Sale = sequelize.define(
  "Sale",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },

    // Other fields specific to the Sale model
    description: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    quantity: {
      type: DataTypes.REAL,
      allowNull: false,
      defaultValue: 1,
    },
    unit_initial_price: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    unit_price: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },

    // Timestamp fields
  },
  {
    tableName: "sales",
    timestamps: true, // Enable Sequelize's default timestamp fields (updatedAt, createdAt)
  }
);

sequelize
  .sync()
  .then(() => {
    console.log("Sale model synced with database");
  })
  .catch((error) => {
    console.error("Error syncing Sale model:", error);
  });

module.exports = Sale;
