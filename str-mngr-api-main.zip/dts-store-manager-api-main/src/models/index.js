const Item = require("./Item");
const Sale = require("./Sale");
const Unit = require("./Unit");

Item.belongsTo(Unit, { foreignKey: "unit_id" });
Unit.hasMany(Item, { foreignKey: "unit_id" });

Sale.belongsTo(Item, { foreignKey: "item_id" });
Item.hasMany(Sale, { foreignKey: "item_id" });
