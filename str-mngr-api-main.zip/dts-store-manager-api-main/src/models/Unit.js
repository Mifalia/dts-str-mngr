const { DataTypes, Sequelize } = require("sequelize");
const sequelize = require("./config");

const Unit = sequelize.define(
  "Unit",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },

    // Other fields of the User model
    unit_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },

    // Timestamp fields
  },
  {
    tableName: "units",
    timestamps: true, // Disable Sequelize's default timestamp fields (updatedAt, createdAt)
  }
);

sequelize
  .sync()
  .then(() => {
    console.log("Unit model synced with database");
  })
  .catch((error) => {
    console.error("Error syncing User model:", error);
  });

module.exports = Unit;
